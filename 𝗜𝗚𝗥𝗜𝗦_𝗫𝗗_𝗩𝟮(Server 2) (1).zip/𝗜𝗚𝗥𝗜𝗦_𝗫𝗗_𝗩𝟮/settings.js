const settings = {
  packname: '𝐈𝐠𝐫𝐢𝐬_𝐗𝐝',
  author: 'NEXUS',
  botName: "𝐈𝐠𝐫𝐢𝐬_𝐗𝐝",
  botOwner: 'NEXUS', // Your name
  ownerNumber: '2349020090826', //Set your number here without + symbol.
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.0",
};

module.exports = settings;
