async function githubCommand(sock, chatId) {
    const repoInfo = `*𝐈𝐠𝐫𝐢𝐬_𝐗𝐝*

*Github:*
╭━━━❰⚡ *IGRIS XD V2 IS HERE!* ⚡❱━━━╮  
┃  
┃ 🚀 *New Commands Unlocked!*  
┃ 🎮 Fun Menu  
┃ 📥 Download Menu  
┃ 👑 Owner Menu  
┃ 👥 Group Menu  
┃  
┃ 🔗 *Pair now & get FREE access to*  
┃ 💠 *300 Servers* – Limited slots!  
┃  
┃ 🤖 *Pair Using Any Server Below:*  
┃ ┗ t.me/IGRIS_XD_BOT  
┃ ┗ t.me/Igris_Xd_server2_bot  
┃ ┗ t.me/Igris_Xd_server3_bot  
┃ ┗ t.me/Igris_Xd_server4_bot  
┃  
┃ ⏳ *Hurry before servers are full!*  
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
Follow Rules and enjoy ✍️`;

    try {
        await sock.sendMessage(chatId, {
            text: repoInfo,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363402232397719@newsletter',
                    newsletterName: '𝐈𝐠𝐫𝐢𝐬_𝐗𝐝',
                    serverMessageId: -1
                }
            }
        });
    } catch (error) {
        console.error('Error in github command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Error fetching repository information.' 
        });
    }
}

module.exports = githubCommand; 