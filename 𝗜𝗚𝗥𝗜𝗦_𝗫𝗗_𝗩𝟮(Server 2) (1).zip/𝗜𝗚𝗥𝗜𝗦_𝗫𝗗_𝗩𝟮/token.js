module.exports = {
  BOT_TOKEN: '8416645646:AAEMaxYF8Xyaqqz6-v0pvSAog78I5RzRyYc',  
  startupPassword: 'nexus'
};